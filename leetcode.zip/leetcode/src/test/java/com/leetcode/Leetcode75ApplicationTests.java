package com.leetcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Leetcode75ApplicationTests {

	@Test
	void contextLoads() {
	}

}
