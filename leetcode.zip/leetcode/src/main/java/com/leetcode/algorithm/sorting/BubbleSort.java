package com.leetcode.algorithm.sorting;

import org.junit.jupiter.api.Assertions;

import java.util.Arrays;

public class BubbleSort {

    public static void main(String[] args) {
        testBubbleSort();
    }

    public static int[] bubbleSort(int[] arr){
        int n = arr.length;
        boolean iswaped = false;
        for(int i=0; i< n; i++){
            for(int j=0; j<n-i-1; j++){

                if(arr[j] > arr[j+1]){
                    iswaped = true;
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
            if(!iswaped){
                break;
            }
        }
        return arr;
    }

    public static void testBubbleSort(){
        int[] arr1 = {64, 25, 12, 22, 11};
        int[] expected1 = {11, 12, 22, 25, 64};
        int[] result1 = BubbleSort.bubbleSort(arr1);
        System.out.println(Arrays.toString(result1));
        Assertions.assertArrayEquals(expected1, result1);
    }
}
