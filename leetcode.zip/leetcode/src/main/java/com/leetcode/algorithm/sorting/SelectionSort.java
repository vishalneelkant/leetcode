package com.leetcode.algorithm.sorting;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

public class SelectionSort {

    public static void main(String[] args) {
        //Write a testcase for selectionSort method
        testSelectionSort();
    }

    public static int[] selectionSort(int[] arr){

        int n = arr.length - 1;

        for(int i=0; i<n; i++){
            int min_idx = i;

            for(int j=i+1; j<arr.length; j++){
                if(arr[j] < arr[min_idx]){
                    min_idx = j;
                }
            }
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }

        return arr;

    }

    public static void testSelectionSort() {
        // Test case 1
        int[] arr1 = {64, 25, 12, 22, 11};
        int[] expected1 = {11, 12, 22, 25, 64};
        int[] result1 = SelectionSort.selectionSort(arr1);
        System.out.println(Arrays.toString(result1));
        Assertions.assertArrayEquals(expected1, result1);

        // Test case 2
        int[] arr2 = {5, 1, 6, 2, 4, 3};
        int[] expected2 = {1, 2, 3, 4, 5, 6};
        int[] result2 = SelectionSort.selectionSort(arr2);
        System.out.println(Arrays.toString(result2));
        Assertions.assertArrayEquals(expected2, result2);

        // Test case 3
        int[] arr3 = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int[] expected3 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] result3 = SelectionSort.selectionSort(arr3);
        System.out.println(Arrays.toString(result3));
        Assertions.assertArrayEquals(expected3, result3);

        // Test case 4
        int[] arr4 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] expected4 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] result4 = SelectionSort.selectionSort(arr4);
        System.out.println(Arrays.toString(result4));
        Assertions.assertArrayEquals(expected4, result4);
    }
}
