package com.leetcode.algorithm.sorting;

import org.junit.jupiter.api.Assertions;

import java.util.Arrays;

public class MergeSort {

    public static void main(String[] args) {
        testMergeSort();
    }

    public static int[] mergeSort(int[] arr, int lo, int hi){

        if(lo==hi){
            int[] br = new int[1];
            br[0] = arr[hi];
            return br;
        }

        int mid = (lo+hi)/2;

        int[] fsh = mergeSort(arr, lo, mid);
        int[] ssh = mergeSort(arr, mid + 1,  hi);
        int [] fsa = mergeSortedArray(fsh, ssh);

        return fsa;
    }

    public static int[] mergeSortedArray(int[] a, int[] b){
        int[] res = new int[a.length + b.length];

        int i=0;
        int j=0;
        int k=0;

        while(i<a.length && j<b.length){
            if(a[i] < b[j]){
                res[k] = a[i];
                i++;
                k++;
            }
            else{
                res[k] = b[j];
                j++;
                k++;
            }
        }

        while(i < a.length){
            res[k] = a[i];
            i++;
            k++;
        }

        while( j < b.length){
            res[k] = b[j];
            j++;
            k++;
        }
        return res;
    }

    public static void testMergeSort() {
        // Test case 1
        int[] arr1 = {64, 25, 12, 22, 11};
        int[] expected1 = {11, 12, 22, 25, 64};
        int[] result1 = InsertionSort.insertionSort(arr1);
        System.out.println("Test case 1 result: " + Arrays.toString(result1));
        Assertions.assertArrayEquals(expected1, result1);

        // Test case 2
        int[] arr2 = {5, 1, 6, 2, 4, 3};
        int[] expected2 = {1, 2, 3, 4, 5, 6};
        int[] result2 = InsertionSort.insertionSort(arr2);
        System.out.println("Test case 2 result: " + Arrays.toString(result2));
        Assertions.assertArrayEquals(expected2, result2);

        // Test case 3
        int[] arr3 = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int[] expected3 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] result3 = InsertionSort.insertionSort(arr3);
        System.out.println("Test case 3 result: " + Arrays.toString(result3));
        Assertions.assertArrayEquals(expected3, result3);

        // Test case 4
        int[] arr4 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] expected4 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] result4 = InsertionSort.insertionSort(arr4);
        System.out.println("Test case 4 result: " + Arrays.toString(result4));
        Assertions.assertArrayEquals(expected4, result4);
    }
}
