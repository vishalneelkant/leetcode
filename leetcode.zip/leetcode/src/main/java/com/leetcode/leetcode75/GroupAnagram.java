package com.leetcode.leetcode75;

import java.util.*;

class GroupAnagram {

    public static void main(String[] args) {
//        String[] strs = {"eat", "tea", "tan", "ate", "nat", "bat"};
//        System.out.println(groupAnagrams(strs));
        int[] arr = {1, 3, 4, 7, 9};
        System.out.println(solve(5,6 ,arr));
    }

    static int solve(int N, int K, int[] arr){
        int left = 0, right = N;
        List<Integer> list = new ArrayList<>();
        while (left < right) {
            int mid = left + (right - left) / 2;
            int missing = arr[mid] - (mid + 1); // Number of missing numbers until index mid

            if (missing < K) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        // At this point, left points to the first index where the number of missing integers is >= K
        list.add(left + K);

        Collections.sort(list);

        return list.get(0);

    }


     static int solve2(int N, int K, int[] arr) {
        int n=arr.length;
        int prev=0,i=0;
        while(i<n){
            if(arr[i]==prev+1){
                i++;
            }

            else{
                K--;
                if(K==0) return prev+1;

            }
            prev++;
        }

        while(K>0){
            K--;
            prev++;
        }

        return prev;
    }


    static int missingK(int n, int k, int[] a)
    {
        int difference = 0, ans = 0, count = k;
        boolean flag = false;

        // case when first number is not 1
        if (a[0] != 1) {
            difference = a[0] - 1;
            if (difference >= count)
                return count;
            count -= difference;
        }

        // iterating over the array
        for (int i = 0; i < n - 1; i++) {
            difference = 0;

            // check if i-th and
            // (i + 1)-th element
            // are not consecutive
            if ((a[i] + 1) != a[i + 1]) {

                // save their difference
                difference += (a[i + 1] - a[i]) - 1;

                // check for difference
                // and given k
                if (difference >= count) {
                    ans = a[i] + count;
                    flag = true;
                    break;
                }
                else
                    count -= difference;
            }
        }

        // if found
        if (flag)
            return ans;
        else
            return -1;
    }

    public static Map<Character, Integer> feqMap(String str){
        Map<Character, Integer> map = new HashMap();

        for(int i=0; i<str.length(); i++){
            Character ch = str.charAt(i);
            map.put(ch, map.getOrDefault(ch,0)+1);
        }
        return map;
    }
    public static List<List<String>> groupAnagrams(String[] strs) {
        Map<Map<Character, Integer>, List<String>> res = new HashMap();

        for(String str : strs){
            Map<Character, Integer> feq = feqMap(str);

            if(res.containsKey(feq)){
                List<String> values = res.get(feq);
                values.add(str);
            }
            else{
                List<String> list = new ArrayList();
                list.add(str);
                res.put(feq, list);
            }

        }
        List<List<String>> ansList = new ArrayList();

        for(Map.Entry<Map<Character, Integer>, List<String>> entry : res.entrySet()){
            ansList.add(entry.getValue());
        }

        return ansList;
    }




}


