package com.leetcode.leetcode75;

import java.util.Arrays;

public class MaxTraffic {

    public static void main(String[] args) {
        long[] x = {7, 8, 9 };
        int exit[] = {8, 7, 6, 10};
        //int n = arrl.length;
        //System.out.println(findMaxGuests(arrl, exit, n));
        //System.out.println(x[0] + x[1] + x[2] + "" );

       System.out.println(solve3(10, 2, 2, 1, 5, 5, 20));
    }

    static int solve3(int S, int cnt1, int cnt2, int cnt3, int cost1, int cost2, int cost3) {
        // DP array to store the minimum cost for each sum up to S
        int[] dp = new int[S + 1];
        Arrays.fill(dp, -1);
        dp[0] = 0;

        // Iterate over each item type
        for (int i = 1; i <= cnt1; i++) {
            for (int j = S; j >= 2 * i; j--) {
                if (dp[j - 2 * i] != -1) {
                    int newCost = dp[j - 2 * i] + i * cost1;
                    dp[j] = dp[j] == -1 ? newCost : Math.min(dp[j], newCost);
                }
            }
        }

        for (int i = 1; i <= cnt2; i++) {
            for (int j = S; j >= 3 * i; j--) {
                if (dp[j - 3 * i] != -1) {
                    int newCost = dp[j - 3 * i] + i * cost2;
                    dp[j] = dp[j] == -1 ? newCost : Math.min(dp[j], newCost);
                }
            }
        }

        for (int i = 1; i <= cnt3; i++) {
            for (int j = S; j >= 5 * i; j--) {
                if (dp[j - 5 * i] != -1) {
                    int newCost = dp[j - 5 * i] + i * cost3;
                    dp[j] = dp[j] == -1 ? newCost : Math.min(dp[j], newCost);
                }
            }
        }

        return dp[S];
    }


    static int solve2(int S, int cnt1, int cnt2, int cnt3, int cost1, int cost2, int cost3) {
        // DP array to store the minimum cost for each sum up to S
        int[] dp = new int[S + 1];
        Arrays.fill(dp, Integer.MAX_VALUE);
        dp[0] = 0;

        // Iterate over each item type
        for (int i = 1; i <= cnt1; i++) {
            for (int j = S; j >= 2 * i; j--) {
                if (dp[j - 2 * i] != Integer.MAX_VALUE) {
                    dp[j] = Math.min(dp[j], dp[j - 2 * i] + i * cost1);
                }
            }
        }

        for (int i = 1; i <= cnt2; i++) {
            for (int j = S; j >= 3 * i; j--) {
                if (dp[j - 3 * i] != Integer.MAX_VALUE) {
                    dp[j] = Math.min(dp[j], dp[j - 3 * i] + i * cost2);
                }
            }
        }

        for (int i = 1; i <= cnt3; i++) {
            for (int j = S; j >= 5 * i; j--) {
                if (dp[j - 5 * i] != Integer.MAX_VALUE) {
                    dp[j] = Math.min(dp[j], dp[j - 5 * i] + i * cost3);
                }
            }
        }

        return dp[S] == Integer.MAX_VALUE ? -1 : dp[S];
    }


    static int solve(int S, int cnt1, int cnt2, int cnt3, int cost1, int cost2, int cost3) {
        int sum = 0, cost = 0, ans = Integer.MAX_VALUE;

        // Limit the counts based on how much of each item type is needed to reach S
        cnt1 = (S / 2 > cnt1) ? cnt1 : S / 2;
        cnt2 = (S / 3 > cnt2) ? cnt2 : S / 3;
        cnt3 = (S / 5 > cnt3) ? cnt3 : S / 5;

        // Loop over all possible combinations of items of type 1
        for (int i = 0; i <= cnt1; i++) {
            sum = 2 * i;
            cost = i * cost1;
            if (sum == S)
                ans = Math.min(cost, ans);

            // Loop over all possible combinations of items of type 2
            for (int j = 0; j <= cnt2; j++) {
                sum = 2 * i + 3 * j;
                cost = i * cost1 + j * cost2;
                if (sum == S)
                    ans = Math.min(cost, ans);

                // Determine how many items of type 3 are needed to reach the remainder
                int k = findRemainderIndex(0, cnt3, (S - sum), 5);
                k = (k == -1) ? 0 : k;
                sum += 5 * k;
                cost += k * cost3;
                if (sum == S)
                    ans = Math.min(cost, ans);
            }
        }

        if (ans == Integer.MAX_VALUE)
            return -1;

        return ans;
    }

    static int findRemainderIndex(int start, int end, int search, int cnt) {
        int mid = start + (end - start) / 2;
        int num = cnt * mid;

        while (start <= end) {
            if (num == search)
                return mid;
            else if (num < search)
                return findRemainderIndex(mid + 1, end, search, cnt);
            else if (num > search)
                return findRemainderIndex(start, mid - 1, search, cnt);
        }

        return -1;
    }


    static int findMaxGuests(int arrl[], int exit[],
                              int n)
    {
        // Sort arrival and exit arrays
        Arrays.sort(arrl);
        Arrays.sort(exit);

        // guests_in indicates number of guests at a time
        int guests_in = 1, max_guests = 1, time = arrl[0];
        int i = 1, j = 0;

        // Similar to merge in merge sort to process
        // all events in sorted order
        while (i < n && j < n)
        {
            // If next event in sorted order is arrival,
            // increment count of guests
            if (arrl[i] <= exit[j])
            {
                guests_in++;

                // Update max_guests if needed
                if (guests_in > max_guests)
                {
                    max_guests = guests_in;
                    time = arrl[i];
                }
                i++; //increment index of arrival array
            }
            else // If event is exit, decrement count
            { // of guests.
                guests_in--;
                j++;
            }
        }

       return time;
    }
}
