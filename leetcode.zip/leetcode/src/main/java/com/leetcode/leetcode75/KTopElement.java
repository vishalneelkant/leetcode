package com.leetcode.leetcode75;

import java.util.*;

public class KTopElement {
    public static void main(String[] args) {
        int[] arr = {4,1,-1,2,-1,2,3};
        int k = 2;
       //Arrays.stream(topKFrequent(arr, k)).forEach(System.out::println);
       Arrays.stream(topKFreqWithHeap(arr, k)).forEach(System.out::println);
    }

    public static int[]  topKFreqWithHeap(int[] nums, int k){
        HashMap<Integer, Integer> feq = new HashMap<>();

        for(int i=0; i<nums.length; i++){
            feq.put(nums[i], feq.getOrDefault(nums[i], 0)+1);
        }

       Queue<Map.Entry<Integer, Integer>> minHeap = new PriorityQueue<>((o1, o2) -> o1.getValue()-o2.getValue());



        for(Map.Entry<Integer, Integer> entry : feq.entrySet()){
            minHeap.offer(entry);

            System.out.println("Before Poll " + minHeap);

            if(minHeap.size()>k){
               minHeap.poll();
            }
            System.out.println("After Poll " + minHeap);
        }



        return minHeap.stream().mapToInt(map -> map.getKey()).limit(k).toArray();
    }

    public static int[]  topKFreqWithMap(int[] nums, int k){
        HashMap<Integer, Integer> feq = new HashMap<>();

        for(int i=0; i<nums.length; i++){
            feq.put(nums[i], feq.getOrDefault(nums[i], 0)+1);
        }

        List<Map.Entry<Integer, Integer>> sortedList = new LinkedList<>(feq.entrySet());

        Collections.sort(sortedList, (o1,o2) -> o2.getValue().compareTo(o1.getValue()));

        System.out.println(sortedList);

        int[] arr = new int[k];

        for(int i=0; i<k; i++){
            arr[i] = sortedList.get(i).getKey();
        }
        return arr;

    }
    public static int[] topKFrequent(int[] nums, int k) {

        Map<Integer, Integer> map = new HashMap();

        for(int i=0; i<nums.length; i++){
            map.put(nums[i], map.getOrDefault(nums[i], 0) + 1);
        }

        //System.out.println(map);

        int[] ans = new int[map.size()+1];

        for(Map.Entry<Integer, Integer> entry : map.entrySet()){
            int feq = entry.getValue();
            //System.out.println(feq);
            ans[feq] = entry.getKey();
        }

        int count=ans.length-1;
        int[] result = new int[k];
        int idx = 0;
        while(count>=k){
            result[idx] = ans[count];
            count--;
            idx++;
        }
        System.out.println(result.length);
        return result;

    }
}


