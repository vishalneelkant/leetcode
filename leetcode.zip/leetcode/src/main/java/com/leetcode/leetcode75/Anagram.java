package com.leetcode.leetcode75;

import java.util.HashMap;
import java.util.Map;

public class Anagram {
    public static void main(String[] args) {
        //testIsAnagram();
        System.out.println(isAnagram("listen", "silent"));
    }

    public static boolean isAnagram(String a, String b){

        Map<Character, Integer> fequencyMap = new HashMap<>();

        for(int i=0 ; i<a.length(); i++){
            Character ch = a.charAt(i);
            fequencyMap.put(ch, fequencyMap.getOrDefault(ch, 0)+1);
        }

        for(int i=0; i<b.length(); i++){
            Character ch = b.charAt(i);

            if(!fequencyMap.containsKey(ch)){
                return false;
            }
            else if (fequencyMap.get(ch)>1){
                fequencyMap.put(ch, fequencyMap.get(ch)-1);
            }
            else{
                fequencyMap.remove(ch);
            }
        }

        return fequencyMap.isEmpty();
    }

    public static void testIsAnagram() {
        // Test case 1: Valid anagrams
        assert isAnagram("listen", "silent") : "Test case 1 failed";

        // Test case 2: Different lengths
        assert !isAnagram("hello", "helloo") : "Test case 2 failed";

        // Test case 3: Different characters
        assert !isAnagram("apple", "pale") : "Test case 3 failed";

        // Test case 4: Same characters, different frequencies
        assert !isAnagram("aabbcc", "abc") : "Test case 4 failed";

        // Test case 5: Empty strings
        assert isAnagram("", "") : "Test case 5 failed";

        // Test case 6: Single character
        assert isAnagram("a", "a") : "Test case 6 failed";
        assert !isAnagram("a", "b") : "Test case 6 failed";

        // Test case 7: Anagrams with different character cases
        assert !isAnagram("Listen", "Silent") : "Test case 7 failed";

        System.out.println("All test cases passed!");
    }
}
