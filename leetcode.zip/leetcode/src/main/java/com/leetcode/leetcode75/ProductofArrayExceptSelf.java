package com.leetcode.leetcode75;

import java.util.List;

public class ProductofArrayExceptSelf {

    public static void main(String[] args) {
        list();
    }


    public static int[] productExceptSelf(int[] nums) {
        int[] pre = new int[nums.length];
        int[] suf = new int[nums.length];
        int[] ans = new int[nums.length];

        for (int i=0; i<nums.length; i++){
            if(i==0){
                pre[i] = 1;
            }
            else{
                pre[i] = nums[i-1] * pre[i-1];
            }
        }

        for(int i=nums.length-1; i>=0; i--){
            if(i==nums.length-1){
                suf[i] = 1;
            }
            else{
                //System.out.println(i);
                suf[i] = nums[i+1] * suf[i+1];
            }
        }

        for(int i=0; i<nums.length; i++){
            ans[i] = pre[i] * suf[i];
        }

        return ans;
    }


    public static void list(){

        List<Integer> num = List.of(1, 2, 11, 10, 5);

         List<String> onesList = num.stream()
                .map( num1 -> num1 + "")
                .filter(str -> str.charAt(0)=='1')
                .toList();



        System.out.println(onesList);
    }

}
