package com.leetcode.leetcode75;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TwoSum {

    public static int[] twoSum(int[] arr, int target){
        int i = 0;
        int j = arr.length - 1;
        int[] ans = new int[2];

        while(j>i){
            if(arr[i] + arr[j] == target){
                ans = new int[]{i, j};
                return ans;
            }
            else{
                if(arr[i] + arr[j] > target){
                    j--;
                }
                else{
                    i++;
                }
            }
        }
        return ans;
    }

    public static int[] twoSumBrute(int[] arr, int target){
        int[] ans = new int[2];

        for(int i=0; i<arr.length; i++){
            for(int j=i+1; j<arr.length; j++){
                if((arr[i] + arr[j])==target){
                    ans[0] = i;
                    ans[1] = j;
                    return ans;
                }
            }
        }
        return ans;
    }

    @Test
    public void testTwoSum() {
        int[] arr = {3,2,4};
        int target = 6;
        int[] expected = {1, 2};
        int[] result = TwoSum.twoSumBrute(arr, target);
        System.out.println(result[0] + " " + result[1]);
        Assertions.assertArrayEquals(expected, result);
    }
}
